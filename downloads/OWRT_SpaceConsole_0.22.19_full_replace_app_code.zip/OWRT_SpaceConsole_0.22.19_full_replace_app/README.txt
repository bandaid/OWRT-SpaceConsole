OWRT Space Console 0.22.19

Purpose
OpenWrt writable overlay storage inspection with a tabbed workbench and selectable visual themes.

Install
sh install_owrt_space_console_0_22_19_FULL_REPLACE_APP.sh

Installed targets
/www/owrt-space.html
/www/cgi-bin/owrt-space
/www/cgi-bin/owrt-space-data

0.22.19 corrections
- Header title and version text now use chrome-specific foreground tokens.
- All shipped themes were audited for key foreground/background contrast pairs.
- Service manual light, caution sheet, steel desk, ink high contrast, amber night, blueprint grid, slate grid, and paper grid remain available in the application.
- User-facing version is Version 0.22.19 only.
