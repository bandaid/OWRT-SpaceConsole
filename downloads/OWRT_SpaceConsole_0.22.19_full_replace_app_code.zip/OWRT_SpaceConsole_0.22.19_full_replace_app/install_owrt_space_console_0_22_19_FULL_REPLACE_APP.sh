#!/bin/sh

n=0
while [ "$n" -lt 10 ]; do echo; n=$((n+1)); done

echo "BEGIN_OWRT_SPACE_CONSOLE_0_22_19_FULL_REPLACE_INSTALL"
echo "RUN_METADATA date=$(date '+%Y%m%d_%H%M%S') host=$(hostname 2>/dev/null)"
echo "BUILD_VERSION=0.22.19"
echo "PURPOSE=full_replace_storage_console_application_theme_contrast_audit_and_header_token_fix"
echo

PAGE="/www/owrt-space.html"
CGI="/www/cgi-bin/owrt-space"
DATA="/www/cgi-bin/owrt-space-data"
CGI_CANDIDATE="/www/cgi-bin/.owrt-space-0-22-19.candidate"
DATA_CANDIDATE="/www/cgi-bin/.owrt-space-data-0-22-19.candidate"
PAGE_CANDIDATE="/www/.owrt-space-0-22-19.html.candidate"
ERR_CANDIDATE="/www/.owrt-space-0-22-19.err.candidate"
RAW_CANDIDATE="/www/.owrt-space-0-22-19.raw.candidate"
FAIL=""

fail_msg() {
 echo "RESULT_FAIL $1"
 FAIL="$1"
}

cleanup_candidates() {
 rm -f "$CGI_CANDIDATE" "$DATA_CANDIDATE" "$PAGE_CANDIDATE" "$ERR_CANDIDATE" "$RAW_CANDIDATE" 2>/dev/null
}

if [ -z "$FAIL" ]; then
 echo "STAGE_1_PRECHECK"
 [ -d /www ] || fail_msg "missing_/www"
 [ -d /www/cgi-bin ] || mkdir -p /www/cgi-bin 2>/dev/null || fail_msg "missing_and_cannot_create_/www/cgi-bin"
 echo "PASS precheck_complete"
 echo
fi

if [ -z "$FAIL" ]; then
 echo "STAGE_2_BUILD_RENDERER_CGI_CANDIDATE"
 cleanup_candidates
 cat > "$CGI_CANDIDATE" <<'CGI_0_22_19_EOF'
#!/bin/sh
# OpenWrt Space Console 0.22.19 renderer.
# Read-only renderer. No deletes, no package installs, no service restarts.

printf 'Content-Type: text/html; charset=utf-8\r\n\r\n'

html_escape() {
 sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'
}

q_param() {
 key="$1"
 printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | awk -F= -v k="$key" '$1==k{print $2; exit}'
}

bytes_to_mib() {
 awk -v k="$1" 'BEGIN{printf "%.2f", (k+0)/1024}'
}

percent_of() {
 awk -v n="$1" -v d="$2" 'BEGIN{if ((d+0)>0) printf "%.1f", ((n+0)*100)/(d+0); else printf "0.0"}'
}

bar_width() {
 awk -v n="$1" -v d="$2" 'BEGIN{if ((d+0)>0){p=((n+0)*100)/(d+0); if(p<0)p=0; if(p>100)p=100; printf "%.1f", p}else printf "0.0"}'
}

classify_path() {
 p="$1"
 case "$p" in
  */usr/lib/*|*/lib/*) echo "Libraries" ;;
  */usr/bin/*|*/usr/sbin/*|*/bin/*|*/sbin/*) echo "Executables" ;;
  */www/*) echo "Web UI" ;;
  */etc/*) echo "Configuration" ;;
  */root/*) echo "Root files" ;;
  */var/log/*|*/log/*) echo "Logs" ;;
  */tmp/*|*/cache/*) echo "Cache" ;;
  *) echo "Other" ;;
 esac
}

basename_safe() {
 p="$1"
 b=${p##*/}
 [ -n "$b" ] && printf '%s' "$b" || printf '%s' "$p"
}

parent_safe() {
 p="$1"
 d=${p%/*}
 [ "$d" = "$p" ] && d="/"
 [ -n "$d" ] && printf '%s' "$d" || printf '/'
}

# Query options kept for future extension. Rendering is read-only.
MODE="$(q_param mode)"
REFRESH="$(q_param refresh)"
[ -n "$MODE" ] || MODE="snapshot"
[ -n "$REFRESH" ] || REFRESH="0"

DF_TARGET="/overlay/upper"
[ -d "$DF_TARGET" ] || DF_TARGET="/overlay"
[ -d "$DF_TARGET" ] || DF_TARGET="/www"
[ -d "$DF_TARGET" ] || DF_TARGET="/"
SCAN_ROOT="/overlay/upper"
[ -d "$SCAN_ROOT" ] || SCAN_ROOT="/www"
[ -d "$SCAN_ROOT" ] || SCAN_ROOT="$DF_TARGET"
[ "$SCAN_ROOT" = "/www" ] && SCAN_NOTE="fallback_www_scan_no_overlay_upper" || SCAN_NOTE="overlay_upper_scan"

DF_LINE="$(df -k "$DF_TARGET" 2>/dev/null | awk 'NR==2{print $1"|"$2"|"$3"|"$4"|"$5"|"$6}')"
FS_NAME="$(printf '%s' "$DF_LINE" | awk -F'|' '{print $1}')"
DF_SIZE_K="$(printf '%s' "$DF_LINE" | awk -F'|' '{print $2+0}')"
DF_USED_K="$(printf '%s' "$DF_LINE" | awk -F'|' '{print $3+0}')"
DF_FREE_K="$(printf '%s' "$DF_LINE" | awk -F'|' '{print $4+0}')"
DF_PCT_RAW="$(printf '%s' "$DF_LINE" | awk -F'|' '{gsub(/%/,"",$5); print $5+0}')"
DF_MOUNT="$(printf '%s' "$DF_LINE" | awk -F'|' '{print $6}')"
SCAN_TOTAL_K="$(du -sk "$SCAN_ROOT" 2>/dev/null | awk '{print $1+0}')"
[ -n "$SCAN_TOTAL_K" ] || SCAN_TOTAL_K=0
GENERATED="$(date '+%Y%m%d_%H%M%S')"

TMP_TOP="/www/.owrt-space-0-22-19-top.$$"
TMP_DEEP="/www/.owrt-space-0-22-19-deep.$$"
TMP_FILES="/www/.owrt-space-0-22-19-files.$$"
TMP_CAT="/www/.owrt-space-0-22-19-cat.$$"
TMP_FS="/www/.owrt-space-0-22-19-fs.$$"
TMP_INV="/www/.owrt-space-0-22-19-inv.$$"
trap 'rm -f "$TMP_TOP" "$TMP_DEEP" "$TMP_FILES" "$TMP_CAT" "$TMP_FS" "$TMP_INV" 2>/dev/null' 0 1 2 3 15

: > "$TMP_TOP"
if [ -d "$SCAN_ROOT" ]; then
 for child in "$SCAN_ROOT"/* "$SCAN_ROOT"/.[!.]* "$SCAN_ROOT"/..?*; do
  [ -e "$child" ] || continue
  du -sk "$child" 2>/dev/null
 done | grep -v '/\.owrt-space' | sort -nr | head -n 80 > "$TMP_TOP"
fi

if [ -d "$SCAN_ROOT" ]; then
 du -k "$SCAN_ROOT" 2>/dev/null | grep -v '/\.owrt-space' | sort -nr | head -n 220 > "$TMP_DEEP"
else
 : > "$TMP_DEEP"
fi

if [ -d "$SCAN_ROOT" ]; then
 find "$SCAN_ROOT" -type f -exec du -k {} \; 2>/dev/null | grep -v '/\.owrt-space' | sort -nr | head -n 220 > "$TMP_FILES"
else
 : > "$TMP_FILES"
fi

df -k 2>/dev/null | awk 'NR>1{print $1"|"$2"|"$3"|"$4"|"$5"|"$6}' > "$TMP_FS"
{
 [ -r /proc/mtd ] && sed 's/^/MTD|/' /proc/mtd 2>/dev/null
 [ -r /proc/partitions ] && awk 'NR>2{print "PART|"$0}' /proc/partitions 2>/dev/null
} > "$TMP_INV"

: > "$TMP_CAT"
add_cat() {
 label="$1"
 path="$2"
 desc="$3"
 if [ -e "$path" ]; then
  k="$(du -sk "$path" 2>/dev/null | awk '{print $1+0}')"
 else
  k=0
 fi
 printf '%s|%s|%s\n' "$k" "$label" "$desc" >> "$TMP_CAT"
}
add_cat "Applications and executables" "$SCAN_ROOT/usr/bin" "User-installed command binaries under writable overlay"
add_cat "System libraries" "$SCAN_ROOT/usr/lib" "Writable overlay libraries and package payload"
add_cat "Web UI files" "$SCAN_ROOT/www" "Static web pages, CGI support, and UI files"
add_cat "Configuration" "$SCAN_ROOT/etc" "Writable configuration files"
add_cat "Root home files" "$SCAN_ROOT/root" "Admin scripts, logs, package drops, and manual files"
add_cat "Package metadata" "$SCAN_ROOT/usr/lib/opkg" "Installed package database and package metadata"
add_cat "Logs and variable data" "$SCAN_ROOT/var" "Runtime logs and variable writable data"
add_cat "Other writable overlay" "$SCAN_ROOT" "Full writable scan root, includes anything not captured above"
sort -nr "$TMP_CAT" > "$TMP_CAT.sorted" 2>/dev/null && mv "$TMP_CAT.sorted" "$TMP_CAT"

render_bar() {
 k="$1"
 total="$2"
 w="$(bar_width "$k" "$total")"
 printf '<div class="bar" aria-label="%s percent"><span style="width:%s%%"></span></div>' "$w" "$w"
}

render_row() {
 rank="$1"; k="$2"; path="$3"; total="$4"; kind="$5"
 name="$(basename_safe "$path" | html_escape)"
 parent="$(parent_safe "$path" | html_escape)"
 path_e="$(printf '%s' "$path" | html_escape)"
 class="$(classify_path "$path" | html_escape)"
 mib="$(bytes_to_mib "$k")"
 pct="$(percent_of "$k" "$total")"
 search="$(printf '%s %s %s %s %s' "$name" "$parent" "$path" "$class" "$mib" | html_escape)"
 printf '<tr data-search="%s">' "$search"
 printf '<td data-label="Rank" data-sort-value="%s">%s</td>' "$rank" "$rank"
 printf '<td data-label="Name" class="nameCell">%s</td>' "$name"
 printf '<td data-label="Parent" class="pathCell">%s</td>' "$parent"
 printf '<td data-label="Full path" class="pathCell fullPath">%s</td>' "$path_e"
 printf '<td data-label="Type">%s</td>' "$class"
 printf '<td data-label="MiB" data-sort-value="%s" class="num">%s</td>' "$mib" "$mib"
 printf '<td data-label="KiB" data-sort-value="%s" class="num">%s</td>' "$k" "$k"
 printf '<td data-label="Share" data-sort-value="%s" class="num">%s%%</td>' "$pct" "$pct"
 printf '<td data-label="Bar">'; render_bar "$k" "$total"; printf '</td>'
 printf '</tr>\n'
}

render_table_from_file() {
 file="$1"; total="$2"; empty_msg="$3"
 if [ ! -s "$file" ]; then
  printf '<div class="empty">%s</div>' "$(printf '%s' "$empty_msg" | html_escape)"
  return
 fi
 printf '<table class="workTable sortableTable"><thead><tr>'
 printf '<th data-sort="num">Rank</th><th data-sort="text">Name</th><th data-sort="text">Parent</th><th data-sort="text">Full path</th><th data-sort="text">Type</th><th data-sort="num">MiB</th><th data-sort="num">KiB</th><th data-sort="num">Share</th><th>Bar</th>'
 printf '</tr></thead><tbody>'
 rank=0
 while IFS= read -r line; do
  k="$(printf '%s' "$line" | awk '{print $1+0}')"
  path="$(printf '%s' "$line" | cut -f2- -d' ')"
  [ -n "$path" ] || continue
  rank=$((rank+1))
  render_row "$rank" "$k" "$path" "$total" "row"
 done < "$file"
 printf '</tbody></table>'
}

render_category_table() {
 if [ ! -s "$TMP_CAT" ]; then
  printf '<div class="empty">No category rows available.</div>'
  return
 fi
 printf '<table class="workTable sortableTable"><thead><tr>'
 printf '<th data-sort="num">Rank</th><th data-sort="text">Category</th><th data-sort="text">Meaning</th><th data-sort="num">MiB</th><th data-sort="num">KiB</th><th data-sort="num">Share</th><th>Bar</th>'
 printf '</tr></thead><tbody>'
 rank=0
 while IFS='|' read -r k label desc; do
  [ -n "$label" ] || continue
  rank=$((rank+1))
  mib="$(bytes_to_mib "$k")"
  pct="$(percent_of "$k" "$SCAN_TOTAL_K")"
  search="$(printf '%s %s %s %s' "$label" "$desc" "$mib" "$k" | html_escape)"
  printf '<tr data-search="%s">' "$search"
  printf '<td data-label="Rank" data-sort-value="%s">%s</td>' "$rank" "$rank"
  printf '<td data-label="Category" class="nameCell">%s</td>' "$(printf '%s' "$label" | html_escape)"
  printf '<td data-label="Meaning">%s</td>' "$(printf '%s' "$desc" | html_escape)"
  printf '<td data-label="MiB" data-sort-value="%s" class="num">%s</td>' "$mib" "$mib"
  printf '<td data-label="KiB" data-sort-value="%s" class="num">%s</td>' "$k" "$k"
  printf '<td data-label="Share" data-sort-value="%s" class="num">%s%%</td>' "$pct" "$pct"
  printf '<td data-label="Bar">'; render_bar "$k" "$SCAN_TOTAL_K"; printf '</td></tr>\n'
 done < "$TMP_CAT"
 printf '</tbody></table>'
}

render_fs_table() {
 if [ ! -s "$TMP_FS" ]; then
  printf '<div class="empty">No filesystem rows available from df -k.</div>'
  return
 fi
 printf '<table class="workTable sortableTable"><thead><tr>'
 printf '<th data-sort="text">Filesystem</th><th data-sort="text">Mount</th><th data-sort="num">Total MiB</th><th data-sort="num">Used MiB</th><th data-sort="num">Free MiB</th><th data-sort="num">Used</th><th>Pressure</th>'
 printf '</tr></thead><tbody>'
 while IFS='|' read -r fs size used free pct mount; do
  pnum="$(printf '%s' "$pct" | tr -d '%' | awk '{print $1+0}')"
  search="$(printf '%s %s %s %s' "$fs" "$mount" "$size" "$pct" | html_escape)"
  printf '<tr data-search="%s">' "$search"
  printf '<td data-label="Filesystem" class="pathCell">%s</td>' "$(printf '%s' "$fs" | html_escape)"
  printf '<td data-label="Mount" class="pathCell">%s</td>' "$(printf '%s' "$mount" | html_escape)"
  printf '<td data-label="Total MiB" data-sort-value="%s" class="num">%s</td>' "$(bytes_to_mib "$size")" "$(bytes_to_mib "$size")"
  printf '<td data-label="Used MiB" data-sort-value="%s" class="num">%s</td>' "$(bytes_to_mib "$used")" "$(bytes_to_mib "$used")"
  printf '<td data-label="Free MiB" data-sort-value="%s" class="num">%s</td>' "$(bytes_to_mib "$free")" "$(bytes_to_mib "$free")"
  printf '<td data-label="Used" data-sort-value="%s" class="num">%s</td>' "$pnum" "$(printf '%s' "$pct" | html_escape)"
  printf '<td data-label="Pressure"><div class="bar"><span style="width:%s%%"></span></div></td>' "$pnum"
  printf '</tr>\n'
 done < "$TMP_FS"
 printf '</tbody></table>'
}

render_inventory_table() {
 if [ ! -s "$TMP_INV" ]; then
  printf '<div class="empty">No flash inventory rows found from /proc/mtd or /proc/partitions.</div>'
  return
 fi
 printf '<table class="workTable sortableTable"><thead><tr><th data-sort="text">Source</th><th data-sort="text">Record</th></tr></thead><tbody>'
 while IFS='|' read -r src line; do
  search="$(printf '%s %s' "$src" "$line" | html_escape)"
  printf '<tr data-search="%s"><td data-label="Source">%s</td><td data-label="Record" class="pathCell">%s</td></tr>\n' "$search" "$(printf '%s' "$src" | html_escape)" "$(printf '%s' "$line" | html_escape)"
 done < "$TMP_INV"
 printf '</tbody></table>'
}

top_count="$(wc -l < "$TMP_TOP" 2>/dev/null | awk '{print $1+0}')"
deep_count="$(wc -l < "$TMP_DEEP" 2>/dev/null | awk '{print $1+0}')"
file_count="$(wc -l < "$TMP_FILES" 2>/dev/null | awk '{print $1+0}')"
fs_count="$(wc -l < "$TMP_FS" 2>/dev/null | awk '{print $1+0}')"
inv_count="$(wc -l < "$TMP_INV" 2>/dev/null | awk '{print $1+0}')"
used_mib="$(bytes_to_mib "$DF_USED_K")"
free_mib="$(bytes_to_mib "$DF_FREE_K")"
total_mib="$(bytes_to_mib "$DF_SIZE_K")"
scan_mib="$(bytes_to_mib "$SCAN_TOTAL_K")"
used_bar="$(bar_width "$DF_USED_K" "$DF_SIZE_K")"
scan_bar="$(bar_width "$SCAN_TOTAL_K" "$DF_USED_K")"

cat <<HTML_HEAD
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>OpenWrt Space Console 0.22.19</title>
<style>
:root {
  color-scheme: dark;
  --bg: #080808;
  --chrome: #000000;
  --chromeText: #ffffff;
  --chromeMuted: #c7c7c7;
  --surface: #111111;
  --surface2: #171717;
  --panel: #0e0e0e;
  --panelHead: #161616;
  --tableBg: #0e0e0e;
  --tableAlt: #121212;
  --tableHead: #000000;
  --tableHeadText: #ffffff;
  --line: #565656;
  --line2: #858585;
  --text: #f7f7f7;
  --heading: #ffffff;
  --muted: #c7c7c7;
  --dim: #999999;
  --path: #f0f0f0;
  --controlBg: #000000;
  --controlText: #ffffff;
  --controlBorder: #898989;
  --activeBg: #f0bd4f;
  --activeText: #000000;
  --green: #f0bd4f;
  --blue: #e6e6e6;
  --amber: #f0bd4f;
  --red: #d85c3b;
  --focus: #f0bd4f;
  --shadow: 0 18px 0 rgba(0, 0, 0, 0.24);
  --barTrack: #050505;
  --barFill1: #f0bd4f;
  --barFill2: #e6e6e6;
  --grid1: rgba(240, 189, 79, 0.075);
  --grid2: rgba(230, 230, 230, 0.04);
  --diag: rgba(240, 189, 79, 0.07);
  --r: 4px;
  --barR: 2px;
  --padCell: 8px 10px;
  --padBox: 10px;
}

body[data-theme="serviceManualLight"] {
  color-scheme: light;
  --bg: #eee5d2;
  --chrome: #332d23;
  --chromeText: #fff6e6;
  --chromeMuted: #d6c8b0;
  --surface: #fffaf0;
  --surface2: #f4ead4;
  --panel: #fffaf0;
  --panelHead: #f4ead4;
  --tableBg: #fffaf0;
  --tableAlt: #fffaf0;
  --tableHead: #372f25;
  --tableHeadText: #fff6e6;
  --line: #372f25;
  --line2: #a9967c;
  --text: #171512;
  --heading: #171512;
  --muted: #6a5f52;
  --dim: #403a32;
  --path: #171512;
  --controlBg: #fffaf0;
  --controlText: #171512;
  --controlBorder: #372f25;
  --activeBg: #b94712;
  --activeText: #fff6e6;
  --green: #2f7a49;
  --blue: #245d78;
  --amber: #b94712;
  --red: #8a2f11;
  --focus: #b94712;
  --shadow: 0 18px 0 rgba(55, 47, 37, 0.16);
  --barTrack: #e0d5c1;
  --barFill1: #b94712;
  --barFill2: #2f7a49;
  --grid1: rgba(55, 47, 37, 0.08);
  --grid2: rgba(55, 47, 37, 0.045);
  --diag: rgba(55, 47, 37, 0.055);
}

body[data-theme="cautionSheet"] {
  color-scheme: light;
  --bg: #f2dfb2;
  --chrome: #3e2809;
  --chromeText: #fff4cf;
  --chromeMuted: #e8c97b;
  --surface: #fff4cf;
  --surface2: #f8dfa0;
  --panel: #fff4cf;
  --panelHead: #f8dfa0;
  --tableBg: #fff4cf;
  --tableAlt: #fff4cf;
  --tableHead: #3e2809;
  --tableHeadText: #fff4cf;
  --line: #3e2809;
  --line2: #b58a41;
  --text: #1b1307;
  --heading: #1b1307;
  --muted: #76572f;
  --dim: #4f381c;
  --path: #1b1307;
  --controlBg: #fff4cf;
  --controlText: #1b1307;
  --controlBorder: #3e2809;
  --activeBg: #c33b16;
  --activeText: #fff4cf;
  --green: #2f7a49;
  --blue: #3d6d77;
  --amber: #c33b16;
  --red: #6f1e10;
  --focus: #c33b16;
  --shadow: 0 18px 0 rgba(62, 40, 9, 0.18);
  --barTrack: #e7d19a;
  --barFill1: #c33b16;
  --barFill2: #8d5300;
  --grid1: rgba(62, 40, 9, 0.08);
  --grid2: rgba(62, 40, 9, 0.045);
  --diag: rgba(62, 40, 9, 0.055);
}

body[data-theme="steelDesk"] {
  color-scheme: light;
  --bg: #d8d7d2;
  --chrome: #1f2428;
  --chromeText: #fff5e7;
  --chromeMuted: #c7ced1;
  --surface: #f3f1eb;
  --surface2: #e4e1d8;
  --panel: #f3f1eb;
  --panelHead: #e4e1d8;
  --tableBg: #f3f1eb;
  --tableAlt: #f3f1eb;
  --tableHead: #1f2428;
  --tableHeadText: #fff5e7;
  --line: #1f2428;
  --line2: #858b8d;
  --text: #181a1c;
  --heading: #181a1c;
  --muted: #62686b;
  --dim: #3b3f42;
  --path: #181a1c;
  --controlBg: #f3f1eb;
  --controlText: #181a1c;
  --controlBorder: #1f2428;
  --activeBg: #8b3a18;
  --activeText: #fff5e7;
  --green: #2f6b55;
  --blue: #2e5e7c;
  --amber: #8b3a18;
  --red: #4a2315;
  --focus: #8b3a18;
  --shadow: 0 18px 0 rgba(31, 36, 40, 0.15);
  --barTrack: #d0d0c8;
  --barFill1: #8b3a18;
  --barFill2: #2f6b55;
  --grid1: rgba(31, 36, 40, 0.08);
  --grid2: rgba(31, 36, 40, 0.045);
  --diag: rgba(31, 36, 40, 0.055);
}

body[data-theme="inkHighContrast"] {
  color-scheme: light;
  --bg: #ffffff;
  --chrome: #000000;
  --chromeText: #ffffff;
  --chromeMuted: #ffffff;
  --surface: #ffffff;
  --surface2: #f1f1f1;
  --panel: #ffffff;
  --panelHead: #e8e8e8;
  --tableBg: #ffffff;
  --tableAlt: #ffffff;
  --tableHead: #000000;
  --tableHeadText: #ffffff;
  --line: #000000;
  --line2: #707070;
  --text: #000000;
  --heading: #000000;
  --muted: #4c4c4c;
  --dim: #1c1c1c;
  --path: #000000;
  --controlBg: #ffffff;
  --controlText: #000000;
  --controlBorder: #000000;
  --activeBg: #000000;
  --activeText: #ffffff;
  --green: #000000;
  --blue: #000000;
  --amber: #000000;
  --red: #000000;
  --focus: #000000;
  --shadow: none;
  --barTrack: #ffffff;
  --barFill1: #000000;
  --barFill2: #000000;
  --grid1: rgba(0, 0, 0, 0.055);
  --grid2: rgba(0, 0, 0, 0.035);
  --diag: rgba(0, 0, 0, 0.04);
}

body[data-theme="amberNight"] {
  color-scheme: dark;
  --bg: #0b0904;
  --chrome: #130e06;
  --chromeText: #fff4d6;
  --chromeMuted: #d4bd91;
  --surface: #1a1208;
  --surface2: #251708;
  --panel: #171008;
  --panelHead: #261706;
  --tableBg: #171008;
  --tableAlt: #1d1308;
  --tableHead: #2a1a08;
  --tableHeadText: #fff4d6;
  --line: #6a4f22;
  --line2: #9b7130;
  --text: #fff3d5;
  --heading: #fff8e8;
  --muted: #d4bd91;
  --dim: #a58f6b;
  --path: #ff9b4a;
  --controlBg: #0d0904;
  --controlText: #fff4d6;
  --controlBorder: #9b7130;
  --activeBg: #f0bd4f;
  --activeText: #170c05;
  --green: #f0bd4f;
  --blue: #ff9b4a;
  --amber: #f0bd4f;
  --red: #d85c3b;
  --focus: #f0bd4f;
  --shadow: 0 18px 0 rgba(0, 0, 0, 0.28);
  --barTrack: #050403;
  --barFill1: #f0bd4f;
  --barFill2: #ff9b4a;
  --grid1: rgba(240, 189, 79, 0.075);
  --grid2: rgba(255, 155, 74, 0.045);
  --diag: rgba(240, 189, 79, 0.06);
}

body[data-theme="blueprintGrid"] {
  color-scheme: dark;
  --bg: #091522;
  --chrome: #0d1b2c;
  --chromeText: #f3f8ff;
  --chromeMuted: #c0cbdb;
  --surface: #14233a;
  --surface2: #182d4b;
  --panel: #14233a;
  --panelHead: #0f1d31;
  --tableBg: #14233a;
  --tableAlt: #102035;
  --tableHead: #0f1d31;
  --tableHeadText: #f3f8ff;
  --line: #405b78;
  --line2: #6f87a5;
  --text: #f3f8ff;
  --heading: #ffffff;
  --muted: #c0cbdb;
  --dim: #95a6bd;
  --path: #98d5ff;
  --controlBg: #091522;
  --controlText: #f3f8ff;
  --controlBorder: #6f87a5;
  --activeBg: #86dbff;
  --activeText: #06101c;
  --green: #86dbff;
  --blue: #98d5ff;
  --amber: #86dbff;
  --red: #ff8c8c;
  --focus: #86dbff;
  --shadow: 0 18px 0 rgba(0, 0, 0, 0.25);
  --barTrack: #07101b;
  --barFill1: #86dbff;
  --barFill2: #98d5ff;
  --grid1: rgba(94, 190, 255, 0.11);
  --grid2: rgba(166, 255, 232, 0.06);
  --diag: rgba(94, 190, 255, 0.08);
}

body[data-theme="slateGrid"] {
  color-scheme: dark;
  --bg: #0a1117;
  --chrome: #111820;
  --chromeText: #f4f7f5;
  --chromeMuted: #c2cfd3;
  --surface: #171f28;
  --surface2: #202a34;
  --panel: #171f28;
  --panelHead: #111820;
  --tableBg: #171f28;
  --tableAlt: #141c24;
  --tableHead: #111820;
  --tableHeadText: #f4f7f5;
  --line: #40505d;
  --line2: #70808c;
  --text: #f4f7f5;
  --heading: #ffffff;
  --muted: #c2cfd3;
  --dim: #83949c;
  --path: #a8d0e8;
  --controlBg: #0a1117;
  --controlText: #f4f7f5;
  --controlBorder: #70808c;
  --activeBg: #ffbd59;
  --activeText: #080a0d;
  --green: #ffbd59;
  --blue: #a8d0e8;
  --amber: #ffbd59;
  --red: #ff675d;
  --focus: #ffbd59;
  --shadow: 0 18px 0 rgba(0, 0, 0, 0.27);
  --barTrack: #05080b;
  --barFill1: #ffbd59;
  --barFill2: #a8d0e8;
  --grid1: rgba(168, 208, 232, 0.065);
  --grid2: rgba(255, 189, 89, 0.05);
  --diag: rgba(255, 189, 89, 0.055);
}

body[data-theme="paperGrid"] {
  color-scheme: light;
  --bg: #e9efec;
  --chrome: #f5f7f4;
  --chromeText: #141b1d;
  --chromeMuted: #354348;
  --surface: #f8fbf8;
  --surface2: #e1e8e4;
  --panel: #f8fbf8;
  --panelHead: #e1e8e4;
  --tableBg: #f8fbf8;
  --tableAlt: #f1f5f2;
  --tableHead: #d1dad6;
  --tableHeadText: #141b1d;
  --line: #8ea09a;
  --line2: #536961;
  --text: #141b1d;
  --heading: #0a1113;
  --muted: #354348;
  --dim: #607074;
  --path: #175b72;
  --controlBg: #f8fbf8;
  --controlText: #141b1d;
  --controlBorder: #536961;
  --activeBg: #17633f;
  --activeText: #ffffff;
  --green: #17633f;
  --blue: #175b72;
  --amber: #8a5b00;
  --red: #8f2b22;
  --focus: #17633f;
  --shadow: 0 18px 0 rgba(40, 65, 74, 0.14);
  --barTrack: #ced9d5;
  --barFill1: #17633f;
  --barFill2: #175b72;
  --grid1: rgba(40, 70, 82, 0.08);
  --grid2: rgba(21, 95, 63, 0.05);
  --diag: rgba(21, 95, 63, 0.05);
}

body[data-shape="soft"] {
  --r: 10px;
  --barR: 6px;
}

body[data-shape="fillet"] {
  --r: 4px;
  --barR: 2px;
}

body[data-shape="square"] {
  --r: 1px;
  --barR: 0px;
}

body[data-density="compact"] {
  --padCell: 6px 8px;
  --padBox: 8px;
  font-size: 12px;
}

body[data-density="comfortable"] {
  --padCell: 10px 12px;
  --padBox: 12px;
}

body[data-density="dense"] {
  --padCell: 5px 7px;
  --padBox: 6px;
  font-size: 12px;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:linear-gradient(90deg,var(--grid1) 1px,transparent 1px) 0 0/40px 40px,linear-gradient(0deg,var(--grid1) 1px,transparent 1px) 0 0/40px 40px,var(--bg);color:var(--text);font:13px/1.42 "IBM Plex Sans","Segoe UI",Roboto,Arial,sans-serif;overflow-x:hidden}
body:before{content:"";position:fixed;inset:0;pointer-events:none;background:linear-gradient(120deg,transparent 0 42%,var(--diag) 42% 43%,transparent 43% 100%);opacity:1}
a{color:inherit}
.shell{position:relative;z-index:1;max-width:1720px;margin:0 auto;padding:0 16px}
.topShell{position:sticky;top:0;z-index:20;background:var(--chrome);border-bottom:1px solid var(--line);box-shadow:var(--shadow)}
.mast{display:grid;grid-template-columns:minmax(260px,1fr) auto;gap:16px;align-items:center;padding:12px 0}
.title h1{margin:0;font-size:21px;letter-spacing:.01em;color:var(--chromeText)}
.title p{margin:3px 0 0;color:var(--chromeMuted);font-size:12px}
.actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end;align-items:center}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;text-decoration:none;border:1px solid var(--controlBorder);background:var(--controlBg);color:var(--controlText);border-radius:var(--r);padding:8px 10px;font-weight:700;min-height:34px}
.btn.primary{border-color:var(--green);box-shadow:inset 0 0 0 1px rgba(255,255,255,.04)}
.filter{min-width:280px;max-width:460px;width:32vw;border:1px solid var(--controlBorder);background:var(--controlBg);color:var(--controlText);border-radius:var(--r);padding:9px 10px}
.filter::placeholder{color:var(--dim)}
.select{border:1px solid var(--controlBorder);background:var(--controlBg);color:var(--controlText);border-radius:var(--r);padding:9px 10px;min-height:34px}
.tabbar{display:flex;flex-wrap:wrap;gap:7px;padding:0 0 12px}
.tab{border:1px solid var(--controlBorder);background:var(--controlBg);color:var(--muted);border-radius:var(--r);padding:7px 10px;font-weight:800;cursor:pointer}
.tab[aria-selected="true"]{color:var(--activeText);background:var(--activeBg);border-color:var(--activeBg)}
main.shell{padding-top:14px;padding-bottom:34px}
.panel{display:none}
.panel.active{display:block}
.summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-bottom:12px}
.metric{background:var(--surface);border:1px solid var(--line);border-radius:var(--r);padding:var(--padBox);min-width:0}
.metric .label{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.07em}
.metric .value{font-size:22px;font-weight:900;margin-top:3px;color:var(--heading)}
.metric .sub{color:var(--dim);font-size:12px;overflow-wrap:anywhere}
.panelBox{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow);overflow:hidden;margin-bottom:14px}
.panelHead{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;border-bottom:1px solid var(--line);background:var(--panelHead);padding:10px 12px}
.panelHead h2{font-size:14px;margin:0;color:var(--heading)}
.panelHead p{margin:2px 0 0;color:var(--muted);font-size:12px}
.panelBody{padding:0}
.note{padding:10px 12px;color:var(--muted);border-bottom:1px solid var(--line);background:var(--surface2)}
.bar{height:12px;background:var(--barTrack);border:1px solid var(--line2);border-radius:var(--barR);overflow:hidden;min-width:74px}
.bar span{display:block;height:100%;background:linear-gradient(90deg,var(--barFill1),var(--barFill2));border-radius:var(--barR)}
.pressure{display:grid;grid-template-columns:220px minmax(0,1fr) 86px;gap:10px;align-items:center;margin-top:8px}
.workTable{width:100%;border-collapse:collapse;table-layout:auto;background:var(--tableBg);color:var(--text)}
.workTable th,.workTable td{border-bottom:1px solid var(--line);padding:var(--padCell);text-align:left;vertical-align:top;color:var(--text)}
.workTable th{font-size:11px;text-transform:uppercase;letter-spacing:.07em;color:var(--tableHeadText);background:var(--tableHead);position:relative}
.workTable th[data-sort]{cursor:pointer}
.workTable th[data-sort]:after{content:"⇅";font-size:10px;color:var(--tableHeadText);opacity:.72;margin-left:6px}
.workTable tr:nth-child(even) td{background:var(--tableAlt)}
.workTable tr:hover td{background:var(--surface2)}
.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.nameCell{font-weight:800;color:var(--heading)}
.pathCell{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px;overflow-wrap:anywhere;word-break:break-word;color:var(--path)}
.fullPath{max-width:560px}
.empty{padding:18px 14px;color:var(--amber);background:var(--surface2);border-top:1px solid var(--line)}
.split{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.textBlock{padding:12px;color:var(--text)}
.cmdGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px}
.cmd{border:1px solid var(--line);border-radius:var(--r);background:var(--surface);overflow:hidden}
.cmd b{display:block;padding:9px 10px;border-bottom:1px solid var(--line);color:var(--heading);background:var(--surface2)}
.cmd pre{margin:0;padding:10px;white-space:pre-wrap;word-break:break-word;color:var(--text);font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px}
.statusLine{display:flex;flex-wrap:wrap;gap:8px;color:var(--muted);font-size:12px}
.pill{border:1px solid var(--line2);border-radius:var(--r);padding:4px 8px;background:var(--controlBg);color:var(--muted)}
.hiddenByFilter{display:none!important}
.srCount{font-size:12px;color:var(--muted)}
.overviewDashboard{display:grid;grid-template-columns:290px minmax(0,1fr);gap:12px;padding:12px}
.donutCard{background:var(--surface);border:1px solid var(--line);border-radius:var(--r);padding:14px;display:grid;place-items:center;gap:8px}
.donutRing{width:176px;height:176px;border-radius:50%;display:grid;place-items:center;position:relative;box-shadow:inset 0 0 0 1px var(--line)}
.donutRing:after{content:"";position:absolute;inset:22px;border-radius:50%;background:var(--panel);border:1px solid var(--line)}
.donutCenter{position:relative;z-index:1;text-align:center;color:var(--text)}
.donutCenter b{display:block;font-size:30px;line-height:1;color:var(--heading)}
.donutCenter span{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}
.legendGrid{display:grid;grid-template-columns:1fr;gap:6px;width:100%;font-size:12px;color:var(--muted)}
.legendRow{display:grid;grid-template-columns:14px 1fr auto;gap:7px;align-items:center}
.legendRow b{color:var(--heading)}
.swatch{width:12px;height:12px;border-radius:3px;background:var(--green)}
.swatch.blue{background:var(--blue)}
.swatch.dim{background:var(--line2)}
.overviewFacts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.factCard{background:var(--surface);border:1px solid var(--line);border-radius:var(--r);padding:12px;min-width:0}
.factCard h3{margin:0 0 7px;font-size:13px;color:var(--heading)}
.factCard p{margin:0;color:var(--text);overflow-wrap:anywhere}
.factList{display:grid;gap:7px}
.factLine{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;border-bottom:1px solid var(--line);padding-bottom:6px;color:var(--muted)}
.factLine:last-child{border-bottom:0;padding-bottom:0}
.factLine b{color:var(--heading);font-variant-numeric:tabular-nums}
.nextCards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:10px}
.nextCard{border:1px solid var(--line2);border-radius:var(--r);background:var(--surface);padding:10px;text-decoration:none;display:block}
.nextCard b{display:block;color:var(--heading);font-size:13px}
.nextCard span{display:block;color:var(--muted);font-size:12px;margin-top:3px}
.overviewMini{padding:0 12px 12px}
.overviewMini .pressure{margin-top:8px}
@media(max-width:980px){.overviewDashboard{grid-template-columns:1fr}
.overviewFacts{grid-template-columns:1fr}
.nextCards{grid-template-columns:1fr}
.mast{grid-template-columns:1fr}
.actions{justify-content:stretch}
.filter{width:100%;max-width:none;min-width:0}
.btn{flex:1 1 auto}
.summary{grid-template-columns:repeat(2,minmax(0,1fr))}
.split,.cmdGrid{grid-template-columns:1fr}
.pressure{grid-template-columns:1fr}
.tabbar{gap:6px}
.tab{flex:1 1 calc(33.333% - 6px)}}
@media(max-width:760px){.donutRing{width:138px;height:138px}
.donutCenter b{font-size:24px}
.shell{padding-left:10px;padding-right:10px}
.summary{grid-template-columns:1fr}
.metric .value{font-size:19px}
.panelHead{grid-template-columns:1fr}
.workTable,.workTable thead,.workTable tbody,.workTable tr,.workTable th,.workTable td{display:block;width:100%}
.workTable thead{display:none}
.workTable tr{border-bottom:1px solid var(--line);padding:8px 0}
.workTable td{display:grid;grid-template-columns:108px minmax(0,1fr);gap:8px;border-bottom:0;padding:5px 10px}
.workTable td:before{content:attr(data-label);color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.06em}
.num{text-align:left;white-space:normal}
.fullPath{max-width:none}
.tab{flex:1 1 calc(50% - 6px);padding:8px 7px}
.topShell{position:sticky}
.actions{gap:6px}
.btn{padding:8px}}
</style>
</head>
<body>
<header class="topShell">
 <div class="shell">
  <div class="mast">
   <div class="title"><h1>OpenWrt Space Console</h1><p>Version 0.22.19</p></div>
   <div class="actions"><input id="globalFilter" class="filter" placeholder="Filter current view by name, path, type, size, or category"><a class="btn primary" href="/cgi-bin/owrt-space?refresh=1">Refresh live scan</a><a class="btn" href="/owrt-space.html">Static snapshot</a></div>
  </div>
  <nav class="tabbar" aria-label="Storage views">
   <button class="tab" data-tab="overview" aria-selected="true">Overview</button>
   <button class="tab" data-tab="top">Top level</button>
   <button class="tab" data-tab="deep">Deep dirs</button>
   <button class="tab" data-tab="files">Files</button>
   <button class="tab" data-tab="categories">Categories</button>
   <button class="tab" data-tab="filesystems">Filesystems</button>
   <button class="tab" data-tab="inventory">Inventory</button>
   <button class="tab" data-tab="cleanup">Cleanup</button>
   <button class="tab" data-tab="options">Options</button>
  </nav>
 </div>
</header>
<main class="shell">
<section id="panel-overview" class="panel active" data-panel="overview">
 <div class="panelBox"><div class="panelHead"><div><h2>Overview</h2><p>Summary page restored. Use this tab for pressure, scan coverage, row counts, and the next investigation path.</p></div><span class="pill">$(printf '%s' "$SCAN_NOTE" | html_escape)</span></div><div class="panelBody">
<section class="summary" aria-label="Storage summary">
 <div class="metric"><div class="label">Writable total</div><div class="value">${total_mib} MiB</div><div class="sub">df target: $(printf '%s' "$DF_TARGET" | html_escape)</div></div>
 <div class="metric"><div class="label">Writable used</div><div class="value">${used_mib} MiB</div><div class="sub">${DF_PCT_RAW}% used on $(printf '%s' "$DF_MOUNT" | html_escape)</div></div>
 <div class="metric"><div class="label">Writable free</div><div class="value">${free_mib} MiB</div><div class="sub">free space reported by df -k</div></div>
 <div class="metric"><div class="label">Scanned content</div><div class="value">${scan_mib} MiB</div><div class="sub">scan root: $(printf '%s' "$SCAN_ROOT" | html_escape)</div></div>
 <div class="metric"><div class="label">Generated</div><div class="value">$(printf '%s' "$GENERATED" | html_escape)</div><div class="sub">mode=$(printf '%s' "$MODE" | html_escape), refresh=$(printf '%s' "$REFRESH" | html_escape)</div></div>
</section>
  <div class="overviewDashboard">
   <div class="donutCard" aria-label="Writable usage donut">
    <div class="donutRing" style="background:conic-gradient(var(--green) 0 ${used_bar}%, rgba(109,200,255,.18) ${used_bar}% 100%)"><div class="donutCenter"><b>${DF_PCT_RAW}%</b><span>writable used</span></div></div>
    <div class="legendGrid">
     <div class="legendRow"><i class="swatch"></i><span>Used writable</span><b>${used_mib} MiB</b></div>
     <div class="legendRow"><i class="swatch blue"></i><span>Free writable</span><b>${free_mib} MiB</b></div>
     <div class="legendRow"><i class="swatch dim"></i><span>Total writable</span><b>${total_mib} MiB</b></div>
    </div>
   </div>
   <div class="overviewFacts">
    <div class="factCard"><h3>Scan scope</h3><div class="factList"><div class="factLine"><span>Scan root</span><b>$(printf '%s' "$SCAN_ROOT" | html_escape)</b></div><div class="factLine"><span>df target</span><b>$(printf '%s' "$DF_TARGET" | html_escape)</b></div><div class="factLine"><span>Mount</span><b>$(printf '%s' "$DF_MOUNT" | html_escape)</b></div></div></div>
    <div class="factCard"><h3>Visible evidence</h3><div class="factList"><div class="factLine"><span>Top branches</span><b>${top_count}</b></div><div class="factLine"><span>Deep directory rows</span><b>${deep_count}</b></div><div class="factLine"><span>File rows</span><b>${file_count}</b></div></div></div>
    <div class="factCard"><h3>Storage math</h3><div class="factList"><div class="factLine"><span>Scanned content</span><b>${scan_mib} MiB</b></div><div class="factLine"><span>Scan vs used</span><b>${scan_bar}%</b></div><div class="factLine"><span>Filesystem rows</span><b>${fs_count}</b></div></div></div>
    <div class="factCard"><h3>Recommended path</h3><p>Start with Top level. If the first branch is too broad, open Deep dirs. If cleanup is needed, confirm exact large files before deleting anything.</p></div>
   </div>
  </div>
  <div class="overviewMini">
   <div class="nextCards"><a class="nextCard" data-jump="top" href="#"><b>Top level</b><span>First branch under the scan root.</span></a><a class="nextCard" data-jump="deep" href="#"><b>Deep dirs</b><span>Largest nested directory offenders.</span></a><a class="nextCard" data-jump="files" href="#"><b>Files</b><span>Actual large files before cleanup.</span></a></div>
  </div>
 </div></div>
</section>
<section id="panel-top" class="panel" data-panel="top">
 <div class="panelBox"><div class="panelHead"><div><h2>Top level branches</h2><p>TreeSize-style first split under the scan root. Use this to decide which branch to inspect.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_HEAD
render_table_from_file "$TMP_TOP" "$SCAN_TOTAL_K" "No top-level branch rows were found. The writable overlay may be empty or the scan root is unavailable."
cat <<HTML_MID1
 </div></div>
</section>
<section id="panel-deep" class="panel" data-panel="deep">
 <div class="panelBox"><div class="panelHead"><div><h2>Deep directories</h2><p>Largest nested directories from the writable scan root.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_MID1
render_table_from_file "$TMP_DEEP" "$SCAN_TOTAL_K" "No deep directory rows were found."
cat <<HTML_MID2
 </div></div>
</section>
<section id="panel-files" class="panel" data-panel="files">
 <div class="panelBox"><div class="panelHead"><div><h2>Largest actual files</h2><p>File-level evidence. This is where oversized archives, logs, packages, and web artifacts become visible.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_MID2
render_table_from_file "$TMP_FILES" "$SCAN_TOTAL_K" "No file rows were found."
cat <<HTML_MID3
 </div></div>
</section>
<section id="panel-categories" class="panel" data-panel="categories">
 <div class="panelBox"><div class="panelHead"><div><h2>Usage categories</h2><p>Plain-language grouping for the most common OpenWrt writable overlay areas.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_MID3
render_category_table
cat <<HTML_MID4
 </div></div>
</section>
<section id="panel-filesystems" class="panel" data-panel="filesystems">
 <div class="panelBox"><div class="panelHead"><div><h2>Filesystems</h2><p>Raw df -k output with pressure bars. This shows mounted capacity, not only overlay scan contents.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_MID4
render_fs_table
cat <<HTML_MID5
 </div></div>
</section>
<section id="panel-inventory" class="panel" data-panel="inventory">
 <div class="panelBox"><div class="panelHead"><div><h2>Flash and block inventory</h2><p>Hardware and partition context from /proc/mtd and /proc/partitions.</p></div><span class="pill tabRows">Rows</span></div><div class="panelBody">
HTML_MID5
render_inventory_table
cat <<HTML_MID6
 </div></div>
</section>
<section id="panel-cleanup" class="panel" data-panel="cleanup">
 <div class="panelBox"><div class="panelHead"><div><h2>Cleanup reference</h2><p>Preview-first commands. Do not delete from /rom to free overlay space.</p></div><span class="pill">Manual only</span></div><div class="panelBody"><div class="note">Commands below are examples for inspection. They do not run from this page.</div><div class="cmdGrid">
  <div class="cmd"><b>Largest overlay directories</b><pre>du -ak /overlay/upper 2&gt;/dev/null | sort -nr | head -n 80</pre></div>
  <div class="cmd"><b>Largest overlay files</b><pre>find /overlay/upper -type f -exec du -k {} \; 2&gt;/dev/null | sort -nr | head -n 80</pre></div>
  <div class="cmd"><b>Installed packages</b><pre>opkg list-installed | sort</pre></div>
  <div class="cmd"><b>Package files before removal</b><pre>opkg files &lt;package_name&gt; 2&gt;/dev/null</pre></div>
  <div class="cmd"><b>Preview one file before delete</b><pre>ls -lh /path/to/file
rm -i /path/to/file</pre></div>
  <div class="cmd"><b>Preview one directory before delete</b><pre>du -sh /path/to/directory
rm -ri /path/to/directory</pre></div>
 </div></div></div>
</section>

<section id="panel-options" class="panel" data-panel="options">
 <div class="panelBox"><div class="panelHead"><div><h2>Interface options</h2><p>Style controls apply tested service manual, steel desk, caution sheet, ink, amber, blueprint, slate, and paper grid palettes. Version 0.22.19.</p></div><span class="pill">Local UI preference</span></div><div class="panelBody"><div class="textBlock">
  <div class="split">
   <label>Theme<br><select id="themeSelect" class="select"><option value="default">Service manual dark</option><option value="serviceManualLight">Service manual light</option><option value="cautionSheet">Caution sheet</option><option value="steelDesk">Steel desk</option><option value="inkHighContrast">Ink high contrast</option><option value="amberNight">Amber night</option><option value="blueprintGrid">Blueprint grid</option><option value="slateGrid">Slate grid</option><option value="paperGrid">Paper grid</option></select></label>
   <label>Shape<br><select id="shapeSelect" class="select"><option value="fillet">Fillet, less round</option><option value="soft">Soft rounded</option><option value="square">Near square</option></select></label>
  </div>
  <div style="height:10px"></div>
  <label>Density<br><select id="densitySelect" class="select"><option value="comfortable">Comfortable</option><option value="compact">Compact</option><option value="dense">Dense</option></select></label>
  <div style="height:12px"></div>
  <button id="resetStyle" class="btn" type="button">Reset style</button>
  <p class="statusLine">These settings are browser-local UI preferences only. They do not change router storage data, delete files, install packages, restart services, or alter OpenWrt configuration.</p>
 </div></div></div>
</section>
</main>
<script>
(function(){
 const prefsKey='owrt_space_console_0_22_19_style';
 const themeSelect=document.getElementById('themeSelect');
 const shapeSelect=document.getElementById('shapeSelect');
 const densitySelect=document.getElementById('densitySelect');
 function loadPrefs(){try{return JSON.parse(localStorage.getItem(prefsKey)||'{}')}catch(e){return {}}}
 function savePrefs(p){try{localStorage.setItem(prefsKey,JSON.stringify(p))}catch(e){}}
 function applyPrefs(p){
  document.body.dataset.theme=p.theme&&p.theme!=='default'?p.theme:'';
  document.body.dataset.shape=p.shape||'fillet';
  document.body.dataset.density=p.density||'comfortable';
  if(themeSelect)themeSelect.value=p.theme||'default';
  if(shapeSelect)shapeSelect.value=p.shape||'fillet';
  if(densitySelect)densitySelect.value=p.density||'comfortable';
 }
 function readPrefs(){return {theme:themeSelect?themeSelect.value:'default',shape:shapeSelect?shapeSelect.value:'fillet',density:densitySelect?densitySelect.value:'comfortable'}}
 applyPrefs(Object.assign({theme:'default',shape:'fillet',density:'comfortable'},loadPrefs()));
 [themeSelect,shapeSelect,densitySelect].forEach(el=>{if(el)el.addEventListener('change',()=>{const p=readPrefs();applyPrefs(p);savePrefs(p);});});
 const resetStyle=document.getElementById('resetStyle');
 if(resetStyle)resetStyle.addEventListener('click',()=>{const p={theme:'default',shape:'fillet',density:'comfortable'};applyPrefs(p);savePrefs(p);});
 const tabs=[...document.querySelectorAll('.tab')];
 const panels=[...document.querySelectorAll('.panel')];
 const filter=document.getElementById('globalFilter');
 function activePanel(){return document.querySelector('.panel.active')}
 function setTab(name){
  tabs.forEach(t=>t.setAttribute('aria-selected',t.dataset.tab===name?'true':'false'));
  panels.forEach(p=>p.classList.toggle('active',p.dataset.panel===name));
  applyFilter();
  window.scrollTo(0,0);
 }
 tabs.forEach(t=>t.addEventListener('click',()=>setTab(t.dataset.tab)));
 document.querySelectorAll('[data-jump]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();setTab(a.dataset.jump);}));
 function cellValue(row,idx,type){
  const c=row.children[idx];
  if(!c)return '';
  const v=c.getAttribute('data-sort-value')||c.textContent.trim();
  return type==='num' ? parseFloat(String(v).replace(/[^0-9.\-]/g,''))||0 : String(v).toLowerCase();
 }
 document.querySelectorAll('th[data-sort]').forEach(th=>{
  th.addEventListener('click',()=>{
   const table=th.closest('table');
   const tbody=table.querySelector('tbody');
   const idx=[...th.parentNode.children].indexOf(th);
   const type=th.dataset.sort;
   const dir=th.dataset.dir==='asc'?'desc':'asc';
   th.dataset.dir=dir;
   [...tbody.children].sort((a,b)=>{
    const av=cellValue(a,idx,type),bv=cellValue(b,idx,type);
    if(type==='num')return dir==='asc'?av-bv:bv-av;
    return dir==='asc'?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av));
   }).forEach(r=>tbody.appendChild(r));
   applyFilter();
  });
 });
 function applyFilter(){
  const q=(filter.value||'').toLowerCase().trim();
  const panel=activePanel();
  let total=0,shown=0;
  if(panel){
   panel.querySelectorAll('tbody tr').forEach(r=>{
    total++;
    const hay=(r.dataset.search||r.textContent||'').toLowerCase();
    const ok=!q||hay.includes(q);
    r.classList.toggle('hiddenByFilter',!ok);
    if(ok)shown++;
   });
  }
  const target=panel?panel.querySelector('.tabRows'):null;
  if(target)target.textContent=total?shown+' of '+total+' rows':'';
 }
 filter.addEventListener('input',applyFilter);
 applyFilter();
})();
</script>
<!-- DATA_READY_0.22.19 -->
</body>
</html>
HTML_MID6
CGI_0_22_19_EOF
 chmod 0755 "$CGI_CANDIDATE" 2>/dev/null || fail_msg "chmod_cgi_candidate_failed"
 sh -n "$CGI_CANDIDATE" 2>&1 || fail_msg "cgi_candidate_syntax_failed"
 [ -z "$FAIL" ] && echo "PASS renderer candidate built"
 echo
fi

if [ -z "$FAIL" ]; then
 echo "STAGE_3_RENDER_STATIC_PAGE_CANDIDATE"
 QUERY_STRING="mode=snapshot" "$CGI_CANDIDATE" > "$RAW_CANDIDATE" 2> "$ERR_CANDIDATE" || fail_msg "static_render_failed"
 awk 'BEGIN{body=0}{line=$0; sub(/\r$/, "", line); if(body){print $0} else if(line==""){body=1}}' "$RAW_CANDIDATE" > "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_header_strip_failed"
 if [ -s "$ERR_CANDIDATE" ]; then
  echo "STATIC_RENDER_STDERR_BEGIN"
  sed -n '1,80p' "$ERR_CANDIDATE" 2>/dev/null
  echo "STATIC_RENDER_STDERR_END"
  fail_msg "static_render_stderr_not_empty"
 fi
 grep -q "DATA_READY_0.22.19" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_data_ready_marker"
 grep -q "color:var(--chromeText)" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "title_not_bound_to_chrome_text"
 grep -q "color:var(--chromeMuted)" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "version_not_bound_to_chrome_muted"
 grep -q "^Content-Type:" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "static_page_contains_cgi_header"
  grep -q "Version 0.22.19" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_version_label"
 grep -q "class=\"tabbar\"" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_tabbar"
 grep -q "data-tab=\"top\"" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_top_tab"
 grep -q "data-panel=\"top\"" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_top_panel"
 grep -q "Refresh live scan" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_refresh_control"
 grep -q "globalFilter" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_filter_control"
 grep -q "th data-sort" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_sort_headers"
 grep -q "themeSelect" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_theme_select"
 grep -q "Service manual dark" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_service_manual_dark_theme"
 grep -q "Service manual light" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_service_manual_light_theme"
 grep -q "Caution sheet" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_caution_sheet_theme"
 grep -q "Steel desk" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_steel_desk_theme"
 grep -q "Ink high contrast" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_ink_high_contrast_theme"
 grep -q "Amber night" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_amber_night_theme"
grep -q "Blueprint grid" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_blueprint_grid_theme"
grep -q "Slate grid" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_slate_grid_theme"
grep -q "Paper grid" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_paper_grid_theme"
 grep -q "body\[data-theme=\"serviceManualLight\"\]" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_service_manual_light_css"
 grep -q "#72e7a7" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "old_green_blue_default_token_present"
 grep -q "donutRing" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_overview_donut"
 grep -q "overviewDashboard" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_overview_dashboard"
 grep -q "shapeSelect" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_shape_select"
 grep -q "densitySelect" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_density_select"
 grep -q "color:var(--text)" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_text_token_binding"
 grep -q "background:var(--panel)" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_panel_token_binding"
 grep -q "data-shape=\"fillet\"" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_fillet_shape_css"
 grep -q "tabRows" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_panel_row_counts"
 grep -q "id=\"rowCount\"" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "global_row_count_still_present"
 grep -q 'class="overviewMini"><div class="pressure"' "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "overview_bottom_pressure_bars_still_present"
 grep -q "@media(max-width:760px)" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_mobile_breakpoint"
 grep -q "overflow-x:hidden" "$PAGE_CANDIDATE" 2>/dev/null || fail_msg "static_missing_page_overflow_guard"
 grep -q "linear-gradient(135deg,var(--bg),var(--chrome))" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "old_body_gradient_still_present"
 grep -q "dataTable" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "old_dataTable_marker_present"
 grep -q "explorerGrid" "$PAGE_CANDIDATE" 2>/dev/null && fail_msg "old_explorerGrid_marker_present"
 [ -z "$FAIL" ] && echo "PASS static page candidate generated and validated"
 echo
fi

if [ -z "$FAIL" ]; then
 echo "STAGE_4_BUILD_DATA_COMPAT_WRAPPER"
 cat > "$DATA_CANDIDATE" <<'DATA_0_22_19_EOF'
#!/bin/sh
QUERY_STRING="${QUERY_STRING:-mode=snapshot}" /www/cgi-bin/owrt-space
DATA_0_22_19_EOF
 chmod 0755 "$DATA_CANDIDATE" 2>/dev/null || fail_msg "chmod_data_candidate_failed"
 sh -n "$DATA_CANDIDATE" 2>&1 || fail_msg "data_candidate_syntax_failed"
 [ -z "$FAIL" ] && echo "PASS data compatibility wrapper built"
 echo
fi

if [ -z "$FAIL" ]; then
 echo "STAGE_5_INSTALL_FULL_REPLACEMENT"
 [ -f "$PAGE" ] && cp "$PAGE" "$PAGE.prev" 2>/dev/null
 [ -f "$CGI" ] && cp "$CGI" "$CGI.prev" 2>/dev/null
 [ -f "$DATA" ] && cp "$DATA" "$DATA.prev" 2>/dev/null
 rm -f "$PAGE" "$CGI" "$DATA" 2>/dev/null
 cp "$CGI_CANDIDATE" "$CGI" 2>/dev/null || fail_msg "install_cgi_failed"
 cp "$PAGE_CANDIDATE" "$PAGE" 2>/dev/null || fail_msg "install_static_page_failed"
 cp "$DATA_CANDIDATE" "$DATA" 2>/dev/null || fail_msg "install_data_endpoint_failed"
 chmod 0644 "$PAGE" 2>/dev/null || fail_msg "chmod_page_failed"
 chmod 0755 "$CGI" "$DATA" 2>/dev/null || fail_msg "chmod_cgi_failed"
 rm -f "$CGI_CANDIDATE" "$PAGE_CANDIDATE" "$DATA_CANDIDATE" "$RAW_CANDIDATE" 2>/dev/null
 [ -z "$FAIL" ] && echo "PASS files installed"
 echo
fi

if [ -z "$FAIL" ]; then
 echo "STAGE_6_FINAL_VALIDATION"
 sh -n "$CGI" 2>&1 || fail_msg "installed_cgi_syntax_failed"
 sh -n "$DATA" 2>&1 || fail_msg "installed_data_syntax_failed"
 grep -q "DATA_READY_0.22.19" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_marker"
 grep -q "^Content-Type:" "$PAGE" 2>/dev/null && fail_msg "installed_static_contains_cgi_header"
  grep -q "Version 0.22.19" "$PAGE" 2>/dev/null || fail_msg "installed_version_label_missing"
 grep -q "class=\"tabbar\"" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_tabbar"
 grep -q "Refresh live scan" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_refresh_control"
 grep -q "themeSelect" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_theme_select"
 grep -q "Service manual dark" "$PAGE" 2>/dev/null || fail_msg "installed_missing_service_manual_dark_theme"
 grep -q "Service manual light" "$PAGE" 2>/dev/null || fail_msg "installed_missing_service_manual_light_theme"
 grep -q "Caution sheet" "$PAGE" 2>/dev/null || fail_msg "installed_missing_caution_sheet_theme"
 grep -q "Steel desk" "$PAGE" 2>/dev/null || fail_msg "installed_missing_steel_desk_theme"
 grep -q "Ink high contrast" "$PAGE" 2>/dev/null || fail_msg "installed_missing_ink_high_contrast_theme"
 grep -q "Amber night" "$PAGE" 2>/dev/null || fail_msg "installed_missing_amber_night_theme"
grep -q "Blueprint grid" "$PAGE" 2>/dev/null || fail_msg "installed_missing_blueprint_grid_theme"
grep -q "Slate grid" "$PAGE" 2>/dev/null || fail_msg "installed_missing_slate_grid_theme"
grep -q "Paper grid" "$PAGE" 2>/dev/null || fail_msg "installed_missing_paper_grid_theme"
 grep -q "#72e7a7" "$PAGE" 2>/dev/null && fail_msg "installed_old_green_blue_default_token_present"
 grep -q "shapeSelect" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_shape_select"
 grep -q "donutRing" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_overview_donut"
 grep -q "tabRows" "$PAGE" 2>/dev/null || fail_msg "installed_static_missing_panel_row_counts"
 grep -q "id=\"rowCount\"" "$PAGE" 2>/dev/null && fail_msg "installed_global_row_count_still_present"
 grep -q 'class="overviewMini"><div class="pressure"' "$PAGE" 2>/dev/null && fail_msg "installed_overview_bottom_pressure_bars_still_present"
 QUERY_STRING="mode=live&refresh=1" "$CGI" 2>/dev/null | grep -q "DATA_READY_0.22.19" || fail_msg "installed_live_cgi_render_failed"
 ls -l "$PAGE" "$CGI" "$DATA" 2>&1
 [ -z "$FAIL" ] && echo "PASS final validation"
 echo
fi

if [ -n "$FAIL" ]; then
 cleanup_candidates
 echo "RESULT_FAIL openwrt_space_console_0_22_19_full_replace_not_installed_or_incomplete reason=$FAIL"
else
 rm -f "$ERR_CANDIDATE" 2>/dev/null
 echo "STATIC_PAGE_URL https://192.168.50.1/owrt-space.html"
 echo "LIVE_REFRESH_URL https://192.168.50.1/cgi-bin/owrt-space?refresh=1"
 echo "RESULT_PASS openwrt_space_console_0_22_19_full_replace_installed"
fi

echo "END_OWRT_SPACE_CONSOLE_0_22_19_FULL_REPLACE_INSTALL"

n=0
while [ "$n" -lt 10 ]; do echo; n=$((n+1)); done
